class User{
    constructor(nom){
        this.nom = nom
    }
    presentation(){
        return 'je suis '+this.nom
    }
}

export default User