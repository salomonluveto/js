export const hello = ()=> alert('hello word')
export const salut = ()=> alert('salut à tous')