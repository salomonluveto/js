let rouge = document.getElementById('rouge')
let noire = document.getElementById('noire')
let vert = document.getElementById('vert')
let div = document.getElementById('fond')

rouge.addEventListener('click', function(){
    di.style.backgroundColor="red"
})
noire.addEventListener('click', function(){
    di.style.backgroundColor="black"
})
vert.addEventListener('click', function(){
    di.style.backgroundColor="green"
})


