
$(document).ready(function() {
	 
	var haut = $(window).height();
	var largeur = $(window).width();
	
	$('#body').css({'height':haut+'px', 'width':largeur+'px'});
	
	$('body').on('click', '.plane', function() {
		var pos = $(this).offset();
		var newTop = pos.top - 50;
		var newLeft = pos.left - 20;
		
		$(this).attr('src', 'images/explosion.gif').css({'top':newTop+'px', 'left':newLeft+'px', 'width':'140px'});
		//console.log(this)
		setTimeout(destroyImg, 2000, this)
		//closeIm(this);
		//$(this).delay(2000).attr('src', '');
	});
 
	function destroyImg(im)
	{
		//alert(im)
		im.remove();
		
	}
	setInterval(function() {
		var aleatoire = Math.random()*haut
		//$('#body').after('<img src="images/plane.png" style="top:'+aleatoire+'px;right:0px;" class="plane fixed" />');
		var plane = $('<img src="images/plane.gif" style="top:'+aleatoire+'px;left:'+largeur+'px;" class="plane fixed" />').animate({left:'-200px'}, 8000)
		//alert(aleatoire);
		$('#body').after(plane);
		setTimeout(destroyImg, 9000, plane)
	}, 1000)
});